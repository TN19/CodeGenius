# A fazer:

- fazer funciona request post
- fazer validação das páginas
- excluir toda parte de courseGenius
